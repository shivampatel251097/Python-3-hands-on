const express = require('express'),
  app = express(),
  bodyParser = require('body-parser');
  port = process.env.PORT || 3307;
var cors = require('cors');
app.use(cors());
app.options('*',cors());
//basic authentication
/*const basicAuth=require('express-basic-auth')
app.use(basicAuth({
	users:{'admin':'Password2$'}
}))
*/
const mysql = require('mysql');
// pool connection configurations
var pool = mysql.createPool({
	connectionLimit:100,
    host: 'vmsappdb.cntuzpgt85ar.ap-southeast-1.rds.amazonaws.com',
    user: 'admin',
    password: 'VMSapp2020',	
    database: 'vmsapp'
});
 
// connect to database
//mc.connect();
exports.pool=pool;
//body parser
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
//Listening Port

var loginRoutes = require('./app/route/loginRoute.js'); //importing route
loginRoutes(app); //register the route

var postActivityRoutes = require('./app/route/postActivityRoute.js'); //importing route
postActivityRoutes(app); //register the route

var eventRoutes = require('./app/route/eventRoute.js'); //importing route
eventRoutes(app); //register the route

var postFeedRoutes = require('./app/route/postFeedRoute.js'); //importing route
postFeedRoutes(app); //register the route

module.exports=app;

app.listen(port);
console.log('API server started on: ' + port);