'user strict';
var sql = require('./db.js');


//Task object constructor
var EventSchedule = function(task){
    this.event_id=task.event_id;
    this.event_type=task.event_type;
    this.event_title=task.event_title;
    this.event_date=task.event_date;
    this.start_time=task.start_time;
    this.end_time=task.end_time;
    this.attendies_list=task.attendies_list;
    this.presenter_id=task.presenter_id;
    this.location_desc=task.location_desc;
    this.event_location=task.event_location;
    this.news_feed=task.news_feed;
};
//Creating a Event list For particular day

EventSchedule.dateWiseEventOfUser=function (reqdata, result){


    console.log("reqdata com is : "+reqdata);
    
    console.log("reqdata is : "+reqdata.event_date);
    console.log("reqdata is : "+reqdata.id);


    sql.query("select *,(select firstname from user_login where id=presenter_id) as presenter,(select GROUP_CONCAT(firstname SEPARATOR ',') from user_login where id in (select guest_id from event_guestMap where eventSchedule_id=event_id)) as 'attendiesName' from event_schedule as ev inner join event_guestMap as eg on ev.event_id=eg.eventSchedule_id where eg.guest_id=? and eg.event_date=?", [reqdata.id,reqdata.event_date], function (err, res) {             
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            var myObj = {};
            myObj.data = res;
            console.log(JSON.stringify(myObj));
            result(null, myObj);
        }
    });
}

//Event Information

EventSchedule.eventInfoUserWise=function (reqdata, result){
    console.log("reqdata is : "+reqdata.event_id);
    sql.query("select *,(select GROUP_CONCAT(firstname SEPARATOR ',') from user_login where id in (select guest_id from event_guestMap where eventSchedule_id=?)) as 'attendiesName' ,(select GROUP_CONCAT(comment SEPARATOR '$*$') from buddy_comments where event_id=? and buddy_id=?) as 'buddyComments' from event_schedule where event_id=?;", [reqdata.event_id,reqdata.event_id,reqdata.buddy_id,reqdata.event_id], function (err, res) {             
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{

            var myObj = {};
            myObj.data = res;
            console.log(JSON.stringify(myObj));
            result(null, myObj);
      
        }
    });
}

module.exports= EventSchedule;