'user strict';
var sql = require('./db.js');

//Task object constructor


var PostActivity=function(task){
    this.id=task.id;
    this.post_id=task.post_id;
    this.action_by=task.action_by;
    this.post_comment=task.post_comment;
    this.post_like=task.post_like;
}


//list all post activity
PostActivity.listAllPostActivity = function (result) {
    sql.query("select sf.post_id,sf.posted_by_id,sf.posted_datetime,sf.post_text,sf.post_images,us.firstname,us.lastname,us.role,us.mail_id,act.action_by,act1.firstname as actionbyfirstname ,act1.lastname as actionbylastname,act.post_comment,act.post_like from user_login us inner join social_feed sf on us.id=sf.posted_by_id left join post_commment_likes act using(post_id) left join user_login act1 on act.action_by=act1.id", function (err, res) {

            if(err) {
                console.log("error: ", err);
                result(null, err);
            }
            else{
                var myObj = {};
                myObj.data = res;
                // console.log(JSON.stringify(myObj));
                result(null, myObj);
            }
        });   
};


//post like
PostActivity.incrementLike = function (post_id,action_by, result) {
     var incLike=1;    
    sql.query("INSERT INTO post_commment_likes set post_id=?,action_by=?, post_like= ?",[post_id,action_by,incLike], function (err, res) {
            if(err) {
                console.log("error: ", err);
                result(err, null);
            }
            else{
                console.log(res.insertId);
                result(null,"Post Liked Successfully");
            }
        });           
};

//delete like
PostActivity.unlikeThePost = function (post_id,action_by, result) {    
    var likedec=1;
   sql.query("DELETE FROM post_commment_likes WHERE post_id=? AND action_by=? AND post_like=?",[post_id,action_by,likedec], function (err, res) {
           if(err) {
               console.log("error: ", err);
               result(err, null);
           }
           else{
               result(null,"Unliked");
           }
       });           
};


//comments On Post
PostActivity.commentsOnPost = function (post_id,action_by,commentonpost, result) {   
   sql.query("INSERT INTO post_commment_likes set post_id=?,action_by=?, post_comment= ?",[post_id,action_by,commentonpost], function (err, res) {
           if(err) {
               console.log("error: ", err);
               result(err, null);
           }
           else{
               console.log(res.insertId);
               result(null,"Commented Successfully");
           }
       });           
};

module.exports=PostActivity;