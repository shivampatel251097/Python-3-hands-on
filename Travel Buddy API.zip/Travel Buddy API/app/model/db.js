'user strict';

var mysql = require('mysql');

//local mysql db connection
var connection = mysql.createConnection({
    host     : 'travelbuddy.cntuzpgt85ar.ap-southeast-1.rds.amazonaws.com',
    user     : 'admin',
    password : 'TravelBuddy$2020',
    database : 'travelbuddy_db'
});

connection.connect(function(err) {
    if (err) throw err;
});
module.exports=connection;