'user strict';
var sql = require('./db.js');

//Task object constructor

var PostFeed=function(task){
    this.post_id=task.post_id;
    this.post_text=task.post_text;
    this.post_images=task.post_images;
    this.posted_by_id=task.posted_by_id;
    this.posted_datetime=task.posted_datetime;
}

//get all posts
PostFeed.listAllPosts = function (result) {
    sql.query("Select * from social_feed", function (err, res) {             
            if(err) {
                console.log("error: ", err);
                result(err, null);
            }
            else{
                var myObj = {};
                myObj.data = res;
                console.log(JSON.stringify(myObj));
                result(null, myObj);
            }
        });   
};

//Creating a user
PostFeed.createNewPost = function (newPost, result) {  
    console.log(newPost);
    let date_ob = new Date();
    let date = ("0" + date_ob.getDate()).slice(-2);
    let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
    let year = date_ob.getFullYear();
    let hours = date_ob.getHours();
    let minutes = date_ob.getMinutes();
    const checkInDate=year+"-"+month+"-"+date+" "+hours+":"+minutes; 
    newPost.posted_datetime=checkInDate

    sql.query("INSERT INTO social_feed set ?",[newPost], function (err, res) {
            if(err) {
                console.log("error: ", err);
                result(err, null);
            }
            else{
                console.log(res.insertId);
                result(null,"New Post created at "+checkInDate+" and Post ID is: "+res.insertId);
            }
        });           
};


//Get All activity of a post
PostFeed.getActivityByViewerId = function (viewer_id,result) {
         sql.query("select *,(select count(*) from post_commment_likes where action_by in (?) and post_id=s.post_id and post_comment is not null) as iscomment ,'' as allcomments,(select count(*) from post_commment_likes where action_by in (?) and post_id=s.post_id and post_like=1) as isliked ,(select concat(firstname,' ',lastname) from user_login where id=posted_by_id) as postedby,(select count(post_comment) from post_commment_likes as pcl where pcl.post_id=s.post_id and post_comment is not null) as totalComments, (select count(post_like) from post_commment_likes as pcl where pcl.post_id=s.post_id and pcl.post_like=1) as totallikes from social_feed as s;", [viewer_id,viewer_id], function (err, res) {             
                 if(err) {
                     console.log("error: ", err);
                     result(err, null);
                 }
                 else{
                     var data= JSON.stringify(res);
                     var mainobj=res;
                     for(let i=0;i<res.length;i++){
                        // console.log(res[i].post_id);
                        sql.query("Select post_comment,(select firstname from user_login where id=action_by) as commentedby from post_commment_likes where post_id=? and post_comment is not null;",[res[i].post_id], function (err, res1) {
                            if(err) {
                                console.log("error: ", err);
                                result(err, null);
                            }
                            else{

                                // var myObj = {};
                                // myObj= res1;
                                // myObj.comment
                                  console.log("res1 "+JSON.stringify(res1)); 
                            
                                // res[i].allcomments=JSON.stringify(res1);


                                // mainobj.comment=JSON.stringify(myObj);

                                // console.log(res1[1].post_comment);
                                // res[i].comments=JSON.stringify(myObj);
                                
                                
                            }
                        }); 
                     }
                     //console.log(mainobj)
                    result(err, res);
                 }
             });   
 };

module.exports=PostFeed;