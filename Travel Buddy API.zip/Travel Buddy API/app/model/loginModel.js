'user strict';
var sql = require('./db.js');

const nodemailer = require("nodemailer");
var smtpTransport = nodemailer.createTransport({
    
    host: "email-smtp.us-east-1.amazonaws.com",
    port:587,
    auth: {
        user: "AKIA5SD5BTPI35GZWNHA",
        pass: "BGN8EEka3ij7Uv+oRSe4tuMDEAuzvz/oRDIxwKFX5nPW"
    }
});

//Task object constructor
var User = function(task){
    this.id=task.id;
    this.firstname=task.firstname;
    this.lastname=task.lastname;
    this.role=task.role;
    this.mail_id=task.mail_id;
    this.phonenumber=task.phonenumber;
    this.createdDate=task.createdDate;
    this.password=task.password;
    this.image_name=task.image_name;
};


//Creating a user
User.createUser = function (new_user, result) {    
    sql.query("INSERT INTO user_login set ?", [new_user], function (err, res) {
            
            if(err) {
                console.log("error: ", err);
                result(err, null);
            }
            else{
                console.log(res.insertId);
                result(null, "User created, ID is:"+ res.insertId);
            }
        });           
};


//list all users
User.getAllUsers = function (result) {
    sql.query("Select * from user_login", function (err, res) {

            if(err) {
                console.log("error: ", err);
                result(null, err);
            }
            else{
                var myObj = {};
                myObj.data = res;
                // console.log(JSON.stringify(myObj)); 
                result(null, myObj);
            }
        });   
};

//Get user by rfID
User.getUserId = function (userId, result) {
        sql.query("Select * from user_login where id=?", [userId], function (err, res) {             
                if(err) {
                    console.log("error: ", err);
                    result(err, null);
                }
                else{
                    var myObj = {};
                    myObj.data = res;
                    // console.log(JSON.stringify(myObj)); 
                    result(null, myObj);
                }
            });   
};

//Validate User With role 
User.validateTheUserWithRole = function (username,password,result) {
    // console.log(username,password,role);
        sql.query("select id,firstname,lastname,phonenumber,mail_id,role,image_name, if(role='Guest',(select id  from user_login where id =(select buddy_id from guestmapbuddy where guest_id=userLogin.id)),(select id from user_login where id =(select guest_id from guestmapbuddy where buddy_id=userLogin.id) )) as mappedid, if(role='Guest',(select firstname  from user_login where id =(select buddy_id from guestmapbuddy where guest_id=userLogin.id)),(select firstname from user_login where id =(select guest_id from guestmapbuddy where buddy_id=userLogin.id) )) as mappedFirstname,if(role='Guest',(select lastname  from user_login where id =(select buddy_id from guestmapbuddy where guest_id=userLogin.id)),(select lastname from user_login where id =(select guest_id from guestmapbuddy where buddy_id=userLogin.id) )) as mappedlastname ,if(role='Guest',(select phonenumber  from user_login where id =(select buddy_id from guestmapbuddy where guest_id=userLogin.id)),(select phonenumber from user_login where id =(select guest_id from guestmapbuddy where buddy_id=userLogin.id) )) as mappedphonenumber,if(role='Guest',(select mail_id  from user_login where id =(select buddy_id from guestmapbuddy where guest_id=userLogin.id)),(select mail_id from user_login where id =(select guest_id from guestmapbuddy where buddy_id=userLogin.id) )) as mappedmail_id ,if(role='Guest',(select role  from user_login where id =(select buddy_id from guestmapbuddy where guest_id=userLogin.id)),(select role from user_login where id =(select guest_id from guestmapbuddy where buddy_id=userLogin.id) )) as mappedrole,if(role='Guest',(select image_name  from user_login where id =(select buddy_id from guestmapbuddy where guest_id=userLogin.id)),(select image_name from user_login where id =(select guest_id from guestmapbuddy where buddy_id=userLogin.id) )) as mappedImage from user_login as userLogin where mail_id=? and password=?;", [username,password], function (err, res) {             
                if(err) {
                    console.log("error: ", err);
                    result(err, null);
                }
                else{
                    var myObj = {};
                    myObj.data = res;
                    // console.log(JSON.stringify(myObj)); 
                    result(null, myObj);
                }
            });   
};

module.exports= User;