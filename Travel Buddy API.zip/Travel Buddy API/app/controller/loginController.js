'use strict';

var User = require('../model/loginModel.js');

//Post    
exports.createUser = function(req, res) {
  var new_user = new User(req.body);
  User.createUser(new_user, function(err, user) {
    if (err)
      res.status(500).send(err);
    else{
      res.status(200).json(user)
    }
  });
};


//Select all
exports.getAllUsers = function(req, res) {
  User.getAllUsers(function(err, user) {
    console.log('controller')
    if (err)
      res.status(500).send(err);
    else{
      res.status(200).json(user);
    }
  });
};


//Get employee by his rfid
exports.getUserId = function(req, res) {
 User.getUserId(req.params.userid, function(err, user) {
    if (err)
      res.status(500).send(err);
    else{  
      res.status(200).json(user);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
    }
  });
};


//Validate a user
exports.validateTheUserWithRole = function(req, res) {
  User.validateTheUserWithRole(req.body.mail_id,req.body.password, function(err, user) {
   //console.log(req.params.password);
    if (err)
      res.status(500).send(err);
    else{  
      res.status(200).json(user);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
    }
});
};

