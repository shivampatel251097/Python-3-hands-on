'use strict';

var PostActivity = require('../model/postActivityModel.js');


//Select all post activity
exports.listAllPostActivity = function(req, res) {
  PostActivity.listAllPostActivity(function(err, postactivity) {
    if (err)
      res.status(500).send(err);
    else{
      res.status(200).send(postactivity);
    }
  });
};


 //Post    
exports.incrementLike = function(req, res) {
  var new_like = new PostActivity(req.body);
  console.log(new_like);
  PostActivity.incrementLike(req.body.post_id, req.body.action_by,function(err, postactivity) {
    if (err)
      res.status(500).send(err);
    else{
      res.status(200).json(postactivity)
    }
   });
};
  // Unlike the post
exports.unlikeThePost = function(req, res) {
  // var new_like = new PostActivity(req.body);
  // console.log(new_like);
  PostActivity.unlikeThePost(req.body.post_id, req.body.action_by,function(err, postactivity) {
    if (err)
      res.status(500).send(err);
    else{
      res.status(200).json(postactivity)
    }
   });
};
//comment on post
exports.commentsOnPost = function(req, res) {
  PostActivity.commentsOnPost(req.body.post_id, req.body.action_by,req.body.post_comment,function(err, postactivity) {
    if (err)
      res.status(500).send(err);
    else{
      res.status(200).json(postactivity)
    }
   });
};


