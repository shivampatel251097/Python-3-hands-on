'use strict';

var EventSchedule = require('../model/eventModel.js');
//Search avaialble user with particular input String



//Day wise events
exports.dateWise_EventOf_User = function(req, res) {

  console.log("post body : "+req.body);
  EventSchedule.dateWiseEventOfUser(req.body, function(err, user) {
     if (err)
      res.send(err);
    res.json(user);
  });
};


//Event Info Of user

exports.eventInfo_UserWise = function(req, res) {
  console.log("post body : "+req.body);
  EventSchedule.eventInfoUserWise(req.body, function(err, user) {
     if (err)
      res.send(err);
    res.json(user);
  });
};
