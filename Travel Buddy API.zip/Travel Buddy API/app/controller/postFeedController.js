'use strict';

var PostActivity = require('../model/postFeedModel.js');



//Select all posts
exports.listAllPosts = function(req, res) {
  PostActivity.listAllPosts(function(err, postactivity) {
    if (err)
      res.status(500).send(err);
    else{
      res.status(200).send(postactivity);
    }
  });
};

//Post    
exports.createNewPost = function(req, res) {
  var new_post = new PostActivity(req.body);
  PostActivity.createNewPost(new_post, function(err, postactivity) {
    if (err)
      res.status(500).send(err);
    else{
      res.status(200).json(postactivity)
    }
  });
};


//Get All activity of a post
exports.getActivityByViewerId = (req, res) => {
  PostActivity.getActivityByViewerId(req.params.viewer_id,function(err, postactivity) {
      if (err)
      res.status(500).send(err);
    else{
      res.status(200).send(postactivity)
        }
     });
   };


