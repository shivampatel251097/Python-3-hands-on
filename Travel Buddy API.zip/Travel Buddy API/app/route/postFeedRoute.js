'use strict';
module.exports = function(app) {
  var PostActivityController = require('../controller/postFeedController.js');

    app.route('/allposts')
    .get(PostActivityController.listAllPosts);
    
    app.route('/newpost')
    .post(PostActivityController.createNewPost);

    app.route('/activity/:viewer_id')
    .get(PostActivityController.getActivityByViewerId);

   };