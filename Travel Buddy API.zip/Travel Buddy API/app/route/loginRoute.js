'use strict';
module.exports = function(app) {
  var LoginController = require('../controller/loginController.js');

    app.route('/user')
    .post(LoginController.createUser)
    .get(LoginController.getAllUsers);

    app.route('/user/:userid')
    .get(LoginController.getUserId);

    //login user
    app.route('/login')
    .post(LoginController.validateTheUserWithRole);
   };