'use strict';
module.exports = function(app) {
  var EventController = require('../controller/eventController.js');

  app.route('/eventScheduleDayWise')
  .post(EventController.dateWise_EventOf_User);

  app.route('/eventInfoUserWise')
  .post(EventController.eventInfo_UserWise);

   };