'use strict';
module.exports = function(app) {
  var PostActivityController = require('../controller/postActivityController.js');

    app.route('/allactivity')
    .get(PostActivityController.listAllPostActivity);

    app.route('/makelike')
    .post(PostActivityController.incrementLike)

    app.route('/makecomment')
    .post(PostActivityController.commentsOnPost)

    app.route('/makeunlike')
    .delete(PostActivityController.unlikeThePost)

   };